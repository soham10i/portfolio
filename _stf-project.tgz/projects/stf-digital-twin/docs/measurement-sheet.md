# STF measurement sheet — one lab session at OTH

Lab access is the scarce resource on this project, not modelling time. Every
number below is currently a guess in `cad/lib/ft_params.scad`, tagged
`[NOMINAL]`. Measuring them once converts the whole model from plausible to
validated, and "validated against the physical cell" is the only sentence here
that a hiring engineer will actually weigh.

Take a **digital caliper**, a **steel rule**, a **stopwatch** (phone is fine),
and a **kitchen scale reading to 1 g**. Budget 90 minutes.

Record answers directly in this file. Anything you cannot measure, write
`SKIP` — an honest gap is worth more than a filled-in guess, because a guess
gets built on.

---

## A. The joint — 15 min, highest value

These four numbers control whether every block in the library looks right.
Measure on a **Baustein 30**, and take each three times on different parts;
mould tolerance is real and one sample will mislead you.

| # | What | Nominal | M1 | M2 | M3 |
|---|---|---|---|---|---|
| A1 | Groove width at the surface (mouth) | 3.6 mm | | | |
| A2 | Groove width at full depth | 5.0 mm | | | |
| A3 | Groove depth into the face | 2.6 mm | | | |
| A4 | Tab projection from the end face | 2.45 mm | | | |
| A5 | Tab height (does it span the full 15 mm?) | 15 mm | | | |

> A caliper cannot reach A2 directly. Either photograph the end grain against
> a rule and measure in pixels, or press modelling clay into the groove and
> measure the cast. The second is faster and more accurate.

**A6 — is the groove profile actually trapezoidal?** Look at the end of a
block. If it is a plain rectangular slot with a separate retaining lip, the
library's profile is wrong in kind, not just in size. Note what you see:

```
(observation)
```

## B. Blocks and plates — 10 min

| # | What | Nominal | Measured |
|---|---|---|---|
| B1 | Baustein 30: length × width × height | 30 × 15 × 15 | |
| B2 | Baustein 15 length | 15 | |
| B3 | Bauplatte thickness | 4.0 mm | |
| B4 | Bauplatte hole diameter | 4.3 mm | |
| B5 | Grundplatte thickness | 5.0 mm | |
| B6 | Grundplatte slot: width × length | 5 × 10 mm | |
| B7 | Grundplatte footprint per station (L × W) | — | |

## C. The workpiece — 10 min, second highest value

The puck sets the suction cup, the rack bay, the conveyor guides and the
ejector stroke. An error here propagates further than any other number.

| # | What | Nominal | Measured |
|---|---|---|---|
| C1 | Diameter | 23.0 mm | |
| C2 | Height | 12.0 mm | |
| C3 | Edge radius | 1.2 mm | |
| C4 | **Mass** (g) — needed for the physics, not the geometry | ? | |
| C5 | Material (ABS? PA?) — sets friction | ? | |
| C6 | How many pucks, in which colours | 9? | |

## D. Aluminium and rails — 10 min

| # | What | Nominal | Measured |
|---|---|---|---|
| D1 | Alu profile cross-section | 15 × 15 mm | |
| D2 | Alu corner radius | 1.5 mm | |
| D3 | VGR horizontal axis: rail length | — | |
| D4 | VGR vertical axis: rail length | — | |
| D5 | Steel guide rod diameter | 4 mm | |

## E. Motion envelopes — 20 min, cannot be guessed at all

Drive each axis to both end stops by hand (power off) and measure travel.
These define the joint limits in the MJCF. Without them the simulation will
happily drive the gripper through the rack.

| # | Axis | Travel | Measured |
|---|---|---|---|
| E1 | VGR Drehkranz — rotation range | degrees | |
| E2 | VGR horizontal axis — stroke | mm | |
| E3 | VGR vertical axis — stroke | mm | |
| E4 | HBW stacker — horizontal stroke | mm | |
| E5 | HBW stacker — vertical stroke | mm | |
| E6 | HBW fork — extend stroke | mm | |
| E7 | HBW rack — bay pitch (X and Z) | mm | |
| E8 | MPO Ofenschieber — stroke | mm | |
| E9 | MPO Sauggreifer rail — stroke | mm | |
| E10 | MPO Drehtisch — rotation range | degrees | |
| E11 | SLD ejector — stroke (each of 3) | mm | |

## F. Timings — 20 min, this is what makes it *behave* right

Run the factory through a full cycle and time each motion, **three runs each**.
Averages go into the MJCF actuator gains; the spread tells us how tight the
control is and is itself worth reporting.

| # | Motion | R1 | R2 | R3 |
|---|---|---|---|---|
| F1 | VGR rotation, full sweep (s) | | | |
| F2 | VGR horizontal, full stroke (s) | | | |
| F3 | VGR vertical, full stroke (s) | | | |
| F4 | Suction: valve on → puck lifted (s) | | | |
| F5 | Suction: valve off → puck released (s) | | | |
| F6 | HBW stacker, one bay to the next (s) | | | |
| F7 | MPO conveyor: puck entry → exit (s) | | | |
| F8 | **MPO conveyor belt speed** (mm/s) — mark the belt, time 100 mm | | | |
| F9 | Oven cycle: slider in → slider out (s) | | | |
| F10 | Saw run time (s) | | | |
| F11 | SLD conveyor speed (mm/s) | | | |
| F12 | Colour sensor → ejector fire, delay (s) | | | |
| F13 | **Full cycle, DPS in → HBW stored** (s) | | | |

> F8 and F11 are the two that matter most. A conveyor in MuJoCo is a tangential
> velocity applied at contact; that number is the velocity. Guess it and every
> transport time in the simulation is wrong by the same factor.

## G. Photographs — 15 min

Not measurements, but they close gaps the caliper cannot. Shoot with the phone
flat-on, not at an angle, and put a steel rule in frame for scale.

- [ ] Each station, straight-on from front, back, left, right, top
- [ ] The Belegungsplan / wiring label sheet, readable
- [ ] The end face of a Baustein 30, close, with rule
- [ ] The HBW rack, straight-on, so bay pitch can be read off
- [ ] The VGR at both rotation end stops
- [ ] The MPO Drehtisch from directly above
- [ ] Any part I have not modelled — pneumatic valve block, compressor,
      the SSC camera mount, the NFC reader on DPS

---

## After the session

Transcribe A–F into `cad/lib/ft_params.scad`, changing each `[NOMINAL]` tag to
`[MEASURED]` as you go. Do not delete the nominal values — keep them in a
trailing comment. When a render later looks wrong, the first question is
always "what changed", and a deleted number cannot answer it.
