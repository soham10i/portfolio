/* Contact sheet: every part in the library, laid out on a grid, so a change to
   ft_params.scad can be eyeballed in one render instead of forty. */
include <../lib/ft_parts.scad>
$fn = FT_FN_FINAL;

module cell(ix, iy) { translate([ix * 90, iy * 90, 0]) children(); }

cell(0,0) ft_baustein_30();
cell(1,0) ft_baustein_15();
cell(2,0) ft_baustein_75();
cell(3,0) ft_winkelstein();
cell(0,1) ft_bauplatte(3,2);
cell(1,1) ft_alu_profile(70);
cell(2,1) ft_zahnstange(60);
cell(3,1) ft_zahnrad(20);
cell(0,2) ft_motor();
cell(1,2) ft_pneumatik_zylinder(stroke=15);
cell(2,2) ft_sauger();
cell(3,2) ft_werkstueck(FT_BLUE);
cell(0,3) ft_lichtschranke();
cell(1,3) ft_taster();
cell(2,3) ft_farbsensor();
cell(3,3) ft_foerderband(len=80,width=40);
cell(0,4) ft_grundplatte(6,4);
