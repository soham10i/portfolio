/* Close-up of the joint. If the dovetail is not actually being cut, everything
   built on this library is wrong, so it gets its own verification render. */
include <../lib/ft_parts.scad>
$fn = FT_FN_FINAL;
ft_baustein_30();
translate([0, 45, 0]) ft_baustein_15(FT_GREY);
translate([0, -45, 0]) rotate([0,0,0]) ft_winkelstein();
