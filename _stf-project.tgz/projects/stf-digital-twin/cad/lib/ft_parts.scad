/* ============================================================================
   fischertechnik — parametric part library
   ----------------------------------------------------------------------------
   The STF is roughly a thousand parts, but only a few dozen *kinds* of part.
   This file defines the kinds. A station is then a list of placements on the
   15 mm raster, which is a data problem rather than a modelling problem — and
   that is the only reason building the whole factory is tractable at all.

   Conventions, applied without exception so that assemblies compose:

     · Origin of every part is the centre of its footprint, sitting ON z = 0,
       growing upward. So `translate([x,y,0]) ft_baustein_30()` puts a block on
       a table, not half-buried in it.
     · Long axis is +X. Height is +Z.
     · Nothing is rotated inside a module. Callers rotate.
     · Every module takes an optional `col` so a caller can override colour
       without editing the library.

   Not modelled, deliberately:
     · Thread detail, moulding draft, ejector-pin marks — invisible at any
       distance the simulation is viewed from, and they multiply triangle count.
     · The interior of motors and sensors. They are opaque boxes; nobody sees in.
   ========================================================================= */

include <ft_params.scad>

/* ─────────────────────────────────────────────────────────────────────────────
   PRIMITIVES
   ───────────────────────────────────────────────────────────────────────── */

/* The dovetail groove, as a 2-D cross-section in the XY plane.

   Drawn as a trapezoid rather than a plain slot because the undercut is the
   entire mechanical point of the joint: a rectangular slot would let a tab pull
   straight out, and the model would then be a lie about how the system works.

   `over` extends the mouth back past the surface it is cut into. Without it the
   cut's outer face is exactly coplanar with the block's face, and OpenGL has no
   way to decide which is in front — the first render came out speckled across
   every top face for exactly this reason. */
module ft_nut_profile(fit = 0, over = 0) {
  m = FT_NUT_MOUTH + 2 * fit;
  i = FT_NUT_INNER + 2 * fit;
  d = FT_NUT_DEPTH + fit;
  polygon([[-m/2, -over], [m/2, -over], [i/2, d], [-i/2, d]]);
}

/* The groove cut, as a solid to subtract, running along X on a face.
   Always used inside difference(); `len` is generous on purpose. */
module ft_nut_cut(len) {
  translate([-len/2, 0, 0])
    rotate([0, 90, 0])
      linear_extrude(height = len)
        rotate([0, 0, 180]) ft_nut_profile(FT_FIT, over = 0.6);
}

/* The mating tab on a block's -X end.

   The first version extruded this along the block's own axis, which cannot be
   right: the tab slides into a groove on *another* block, and that groove runs
   perpendicular to this block. So the prism axis is Z here — the tab is a
   full-height dovetail ridge that slides down (or along) the receiving groove.
   Projection is one groove depth less the fit clearance, so it seats. */
module ft_zapfen(len = FT_BLOCK_H, col = FT_RED) {
  d = FT_NUT_DEPTH - FT_FIT;
  color(col)
    linear_extrude(height = len)
      polygon([[0, -(FT_NUT_MOUTH - 2*FT_FIT)/2],
               [0,  (FT_NUT_MOUTH - 2*FT_FIT)/2],
               [-d, (FT_NUT_INNER - 2*FT_FIT)/2],
               [-d, -(FT_NUT_INNER - 2*FT_FIT)/2]]);
}

/* A rounded-corner box, used often enough to be worth naming. */
module ft_rbox(size, r = 1, fn = FT_FN) {
  hull()
    for (dx = [-1, 1], dy = [-1, 1], dz = [-1, 1])
      translate([dx * (size[0]/2 - r), dy * (size[1]/2 - r), dz * (size[2]/2 - r)])
        sphere(r = r, $fn = fn);
}

/* ─────────────────────────────────────────────────────────────────────────────
   BAUSTEINE — the structural blocks that make up most of the visible mass
   ───────────────────────────────────────────────────────────────────────── */

/* The generic block.

   `faces` selects which of the four long faces carry a groove, as
   [+Y, -Y, +Z, -Z]. The real parts differ in exactly this: a Baustein 30 has
   grooves on all four, while some variants are blind on one face so they can sit
   flush. Making it an argument means one module covers the family. */
module ft_baustein(len = FT_LEN_30, faces = [true, true, true, true], col = FT_RED) {
  w = FT_BLOCK_W; h = FT_BLOCK_H;
  color(col) difference() {
    translate([0, 0, h/2]) cube([len, w, h], center = true);

    if (faces[0]) translate([0,  w/2, h/2]) rotate([180, 0, 0]) ft_nut_cut(len + 2);
    if (faces[1]) translate([0, -w/2, h/2])                     ft_nut_cut(len + 2);
    if (faces[2]) translate([0, 0, h])      rotate([ 90, 0, 0]) ft_nut_cut(len + 2);
    if (faces[3]) translate([0, 0, 0])      rotate([-90, 0, 0]) ft_nut_cut(len + 2);
  }
  // The tab on the -X end. Every block has exactly one, which is what makes
  // the system directional: blocks chain in one direction and butt in the other.
  translate([-len/2, 0, 0]) ft_zapfen(FT_BLOCK_H, col);
}

module ft_baustein_30(col = FT_RED) { ft_baustein(FT_LEN_30, col = col); }
module ft_baustein_15(col = FT_RED) { ft_baustein(FT_LEN_15, col = col); }
module ft_baustein_75(col = FT_RED) { ft_baustein(FT_LEN_75, col = col); }

/* Winkelstein 30° / 60° / 90° — the corner pieces. The STF frames are almost
   entirely 90°, so that is the default. */
module ft_winkelstein(angle = 90, col = FT_RED) {
  w = FT_BLOCK_W;
  color(col) {
    translate([0, 0, w/2]) cube([w, w, w], center = true);
    rotate([0, 0, angle])
      translate([w/2, 0, w/2]) cube([w, w, w], center = true);
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   PLATES
   ───────────────────────────────────────────────────────────────────────── */

/* Bauplatte — the perforated flat plate, nx by ny raster units.
   Holes on the raster, which is what lets anything bolt anywhere. */
module ft_bauplatte(nx = 2, ny = 2, col = FT_RED) {
  lx = nx * FT_RASTER; ly = ny * FT_RASTER;
  color(col) difference() {
    translate([0, 0, FT_PLATE_T/2]) cube([lx, ly, FT_PLATE_T], center = true);
    for (i = [0 : nx - 1], j = [0 : ny - 1])
      translate([-lx/2 + FT_RASTER * (i + 0.5),
                 -ly/2 + FT_RASTER * (j + 0.5), -1])
        cylinder(d = FT_PLATE_HOLE, h = FT_PLATE_T + 2, $fn = FT_FN);
  }
}

/* Grundplatte — the black slotted baseplate each station stands on. The slots
   run in X and repeat on the raster; that is what the photographs show and it
   is what lets a station be re-clamped a few millimetres either way. */
module ft_grundplatte(nx = 20, ny = 14, col = FT_BLACK) {
  lx = nx * FT_RASTER; ly = ny * FT_RASTER;
  color(col) difference() {
    translate([0, 0, FT_BASE_T/2]) cube([lx, ly, FT_BASE_T], center = true);
    for (i = [0 : nx - 1], j = [0 : ny - 1])
      translate([-lx/2 + FT_RASTER * (i + 0.5),
                 -ly/2 + FT_RASTER * (j + 0.5), -1])
        hull() for (s = [-1, 1])
          translate([s * (FT_BASE_SLOT_L - FT_BASE_SLOT_W) / 2, 0, 0])
            cylinder(d = FT_BASE_SLOT_W, h = FT_BASE_T + 2, $fn = FT_FN);
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   ALUMINIUM — the silver rails on the VGR axes and the MPO suction slide
   ───────────────────────────────────────────────────────────────────────── */

module ft_alu_profile(len = 120, col = FT_SILVER) {
  w = FT_ALU_W;
  color(col)
    translate([0, 0, w/2])
      hull() for (dy = [-1, 1], dz = [-1, 1])
        translate([0, dy * (w/2 - FT_ALU_FILLET), dz * (w/2 - FT_ALU_FILLET)])
          rotate([0, 90, 0])
            cylinder(r = FT_ALU_FILLET, h = len, center = true, $fn = FT_FN);
}

/* The polished steel guide rods the vertical axis slides on. */
module ft_guide_rod(len = 150, d = 4, col = FT_SILVER) {
  color(col) rotate([0, 90, 0]) cylinder(d = d, h = len, center = true, $fn = FT_FN);
}

/* ─────────────────────────────────────────────────────────────────────────────
   DRIVE — rack, pinion, motor
   ───────────────────────────────────────────────────────────────────────── */

/* Zahnstange — the toothed rack. Visible along the HBW base and the VGR
   horizontal axis in the photographs. Teeth are drawn as simple trapezoids:
   at the scale this is viewed, involute profiles cost triangles and buy nothing,
   and the physics never touches this geometry. */
module ft_zahnstange(len = 60, col = FT_BLACK) {
  p = PI * FT_MODULE;                 // circular pitch
  n = floor(len / p);
  color(col) {
    translate([0, 0, FT_RACK_H/2]) cube([len, FT_RACK_W, FT_RACK_H], center = true);
    for (i = [0 : n - 1])
      translate([-len/2 + p * (i + 0.5), 0, FT_RACK_H])
        linear_extrude(height = FT_MODULE * 2)
          polygon([[-p*0.30, 0], [p*0.30, 0], [p*0.18, 0.001], [-p*0.18, 0.001]]);
  }
}

/* Zahnrad — a pinion. Same simplification as the rack. */
module ft_zahnrad(teeth = 20, width = 5, col = FT_BLACK) {
  r = FT_MODULE * teeth / 2;
  color(col) {
    cylinder(r = r - FT_MODULE, h = width, $fn = FT_FN * 2);
    for (i = [0 : teeth - 1])
      rotate([0, 0, 360 * i / teeth])
        translate([r - FT_MODULE / 2, 0, width/2])
          cube([FT_MODULE * 2, FT_MODULE * 1.6, width], center = true);
  }
}

/* The 24V encoder motor — the black brick with the blue gearbox in the photos.
   Opaque box: nothing about its interior reaches the render or the physics. */
module ft_motor(col = FT_BLACK) {
  color(col) translate([0, 0, 15]) cube([60, 30, 30], center = true);
  color(FT_BLUE) translate([33, 0, 15]) cube([12, 24, 24], center = true);
  color(FT_SILVER) translate([-33, 0, 15]) rotate([0, 90, 0])
    cylinder(d = 4, h = 10, center = true, $fn = FT_FN);
}

/* ─────────────────────────────────────────────────────────────────────────────
   PNEUMATICS — cylinder, valve, suction cup
   ───────────────────────────────────────────────────────────────────────── */

/* The pneumatic cylinder. `stroke` is the *current* extension, not the maximum:
   the caller animates it, so a station file can render any pose. This is the
   pattern for every actuated part in the library. */
module ft_pneumatik_zylinder(bore = 12, body = 45, stroke = 0, col = FT_SILVER) {
  color(col) {
    translate([0, 0, body/2]) cylinder(d = bore, h = body, center = true, $fn = FT_FN);
    translate([0, 0, body + stroke/2]) cylinder(d = 4, h = stroke + 0.01, center = true, $fn = FT_FN);
  }
  color(FT_RED) translate([0, 0, body + stroke + 2]) cylinder(d = 8, h = 4, $fn = FT_FN);
}

/* Sauger — the suction cup. This is the part the whole VGR exists to position,
   and in simulation it is where the honest approximation lives: no engine
   models vacuum, so the MJCF will weld the workpiece to this body on proximity.
   The geometry here is only what the eye sees. */
module ft_sauger(col = FT_WHITE) {
  color(col) {
    cylinder(d1 = 14, d2 = 9, h = 6, $fn = FT_FN);
    translate([0, 0, 6]) cylinder(d = 9, h = 6, $fn = FT_FN);
  }
  color(FT_BLUE) translate([0, 0, 12]) cylinder(d = 5, h = 8, $fn = FT_FN);
}

/* ─────────────────────────────────────────────────────────────────────────────
   SENSORS
   ───────────────────────────────────────────────────────────────────────── */

module ft_lichtschranke(col = FT_BLACK) {          // photo-interrupter
  color(col) translate([0, 0, 7.5]) cube([8, 12, 15], center = true);
  color(FT_RED) translate([4.5, 0, 7.5]) cube([1, 6, 6], center = true);
}

module ft_taster(col = FT_BLACK) {                 // limit switch / Referenzschalter
  color(col) translate([0, 0, 6]) cube([15, 8, 12], center = true);
  color(FT_RED) translate([8, 0, 6]) cube([2, 4, 8], center = true);
}

module ft_farbsensor(col = FT_BLACK) {             // Farberkennung, SLD
  color(col) translate([0, 0, 7.5]) cube([12, 15, 15], center = true);
  color(FT_BLUE) translate([0, 0, 0.5]) cylinder(d = 6, h = 1, $fn = FT_FN);
}

/* ─────────────────────────────────────────────────────────────────────────────
   THE WORKPIECE — the "cookie"
   ───────────────────────────────────────────────────────────────────────── */

module ft_werkstueck(col = FT_WHITE) {
  color(col)
    hull() {
      translate([0, 0, FT_WP_R])
        cylinder(r = FT_WP_D/2 - FT_WP_R, h = 0.01, $fn = FT_FN * 2);
      translate([0, 0, FT_WP_H - FT_WP_R])
        cylinder(r = FT_WP_D/2 - FT_WP_R, h = 0.01, $fn = FT_FN * 2);
      translate([0, 0, FT_WP_R])
        rotate_extrude($fn = FT_FN * 2)
          translate([FT_WP_D/2 - FT_WP_R, 0]) circle(r = FT_WP_R, $fn = FT_FN);
      translate([0, 0, FT_WP_H - FT_WP_R])
        rotate_extrude($fn = FT_FN * 2)
          translate([FT_WP_D/2 - FT_WP_R, 0]) circle(r = FT_WP_R, $fn = FT_FN);
    }
}

/* ─────────────────────────────────────────────────────────────────────────────
   CONVEYOR — Förderband
   ───────────────────────────────────────────────────────────────────────── */

/* `phase` shifts the visible belt lugs so a caller can animate travel without
   rebuilding geometry — the same trick the MJCF uses for the belt surface. */
module ft_foerderband(len = 180, width = 60, h = 30, phase = 0, col = FT_BLACK) {
  color(col) {
    translate([0, 0, h - 4]) cube([len, width, 8], center = true);            // belt
    for (s = [-1, 1])                                                        // side frames
      translate([0, s * (width/2 + 4), h/2]) cube([len, 8, h], center = true);
    for (s = [-1, 1])                                                        // end rollers
      translate([s * len/2, 0, h - 4]) rotate([90, 0, 0])
        cylinder(d = 14, h = width, center = true, $fn = FT_FN);
  }
  pitch = 20;
  n = floor(len / pitch);
  color(FT_GREY)
    for (i = [0 : n - 1]) {
      x = -len/2 + ((i * pitch + phase) % len);
      translate([x, 0, h]) cube([2, width - 4, 1.5], center = true);
    }
}
