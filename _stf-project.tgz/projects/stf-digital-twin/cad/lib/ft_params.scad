/* ============================================================================
   fischertechnik — dimensional constants
   ----------------------------------------------------------------------------
   EVERY uncertain number in this library lives in this one file, and each is
   tagged with how well it is known:

     [EXACT]     published or geometrically forced; safe to build on
     [MEASURED]  filled in from the physical kit — see docs/measurement-sheet.md
     [NOMINAL]   my best estimate, NOT yet verified against a real part

   The [NOMINAL] values are the ones that will make a printed part not fit and
   an assembly look subtly wrong. They are deliberately isolated here so that
   one session with the kit and a caliper corrects the entire library at once,
   rather than hunting constants through forty modules.

   Units: millimetres throughout. OpenSCAD is unitless; every downstream
   consumer (STL, glTF, MJCF) is told the scale explicitly at export.
   ========================================================================= */

/* ── the raster ──────────────────────────────────────────────────────────── */

// [EXACT] The 15 mm grid the whole system is named for. Baustein 30 is two of
// these long; the perforated plates repeat on it; every station in the STF is
// laid out on it. If one number in this file is right, it is this one.
FT_RASTER      = 15;

// [EXACT] The diagonal raster used by the S-Streben (angled struts):
// 15 * sqrt(2) = 21.213…, which is what makes 45° bracing land back on grid.
FT_RASTER_DIAG = FT_RASTER * sqrt(2);

/* ── the joint ───────────────────────────────────────────────────────────────
   The fischertechnik connection is a dovetail: a tapered groove (Nut) cut into
   the faces of a block, and a matching tapered tab (Zapfen) that slides in from
   the end. It resists pull-out in two axes and slides in the third.

   These are the numbers I am least sure of. The profile is a trapezoid — narrow
   at the mouth, wider inside — but the exact mouth width, depth and flank angle
   I have not verified. Treat every value in this block as provisional.
   ------------------------------------------------------------------------- */

FT_NUT_MOUTH   = 3.6;   // [NOMINAL] slot width at the surface
FT_NUT_INNER   = 5.0;   // [NOMINAL] slot width at full depth
FT_NUT_DEPTH   = 2.6;   // [NOMINAL] how far the slot cuts into the face
FT_ZAPFEN_LEN  = 4.6;   // [NOMINAL] how far the tab projects from its block
FT_FIT         = 0.15;  // [NOMINAL] clearance per side, so a tab slides

/* ── blocks ──────────────────────────────────────────────────────────────── */

// [EXACT, by definition of the system] A Baustein is 15 mm square in section.
FT_BLOCK_W     = 15;
FT_BLOCK_H     = 15;

// Standard lengths, all multiples (or halves) of the raster.
FT_LEN_75      = 7.5;
FT_LEN_15      = 15;
FT_LEN_30      = 30;
FT_LEN_60      = 60;

/* ── plates ──────────────────────────────────────────────────────────────── */

FT_PLATE_T     = 4.0;   // [NOMINAL] Bauplatte thickness
FT_PLATE_HOLE  = 4.3;   // [NOMINAL] the round hole in a perforated plate

// The black baseplate every station is built on. In the photos the stations sit
// on plates of roughly 350 x 250 mm; the exact footprint per station is a
// [MEASURED] item, so the module takes the raster count as an argument rather
// than hard-coding a size here.
FT_BASE_T      = 5.0;   // [NOMINAL] baseplate thickness
FT_BASE_SLOT_W = 5.0;   // [NOMINAL] width of the elongated slots in the base
FT_BASE_SLOT_L = 10.0;  // [NOMINAL] length of those slots

/* ── the workpiece — this is the "cookie" ────────────────────────────────────
   The STF circulates cylindrical pucks in white, red and blue. They are the
   thing the whole cell exists to move, so their dimensions set the suction cup,
   the rack bay, the conveyor guides and the ejector stroke. Getting these wrong
   propagates further than any other number here.
   ------------------------------------------------------------------------- */

FT_WP_D        = 23.0;  // [NOMINAL] workpiece diameter
FT_WP_H        = 12.0;  // [NOMINAL] workpiece height
FT_WP_R        = 1.2;   // [NOMINAL] edge radius

/* ── aluminium ───────────────────────────────────────────────────────────────
   The silver rails on the VGR vertical/horizontal axes and the MPO suction rail.
   Read off the photographs as ~15 mm square with rounded corners and a groove
   per face; the exact section is [MEASURED].
   ------------------------------------------------------------------------- */

FT_ALU_W       = 15.0;  // [NOMINAL]
FT_ALU_FILLET  = 1.5;   // [NOMINAL]

/* ── gears and racks ─────────────────────────────────────────────────────── */

FT_MODULE      = 1.0;   // [NOMINAL] gear module — sets tooth size
FT_RACK_H      = 7.0;   // [NOMINAL] rack body height below the tooth root
FT_RACK_W      = 7.5;   // [NOMINAL] rack width

/* ── colours ─────────────────────────────────────────────────────────────────
   Sampled from the reference photographs, not from a brand guide. They only
   affect preview renders and the glTF export; nothing dimensional. */

FT_RED         = "#c8102e";
FT_BLACK       = "#1c1c1c";
FT_GREY        = "#4a4a4a";
FT_SILVER      = "#c9ccd1";
FT_BLUE        = "#1b52a4";   // pneumatic tubing, blue workpieces
FT_WHITE       = "#ececec";
FT_YELLOW      = "#e8b800";   // the yellow workpiece on the VGR photo

/* ── render quality ──────────────────────────────────────────────────────────
   Two settings, because the same source feeds two very different consumers:
   a fast preview while iterating, and a dense mesh for the web export. The
   collision meshes never come from here at all — they are primitives written
   directly into the MJCF. */

FT_FN_DRAFT    = 16;
FT_FN_FINAL    = 64;
FT_FN          = FT_FN_DRAFT;
