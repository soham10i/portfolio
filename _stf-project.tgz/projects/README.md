# projects/ — private working material

This folder holds the source material for the projects the public portfolio
*describes*: CAD, simulation scenes, extracted control logic, measurement
sheets, reference photography. The site links to write-ups and rendered video.
It never links here.

## Why it is unreachable

Two independent barriers, because one is not a guarantee:

1. **Not served.** `backend/server.js` serves `app/dist` and nothing else
   (`express.static(dist)`). A path outside that tree has no route. Even a
   guessed URL returns the SPA fallback, not a file.
2. **Not tracked.** `projects/` is in `.gitignore`, so a public GitHub remote
   cannot expose it either. This matters more than the first barrier — a
   published repo leaks everything in it, permanently, to anyone who clones.

The cost is real and should be stated: **no version history.** If this material
becomes worth versioning — and once the STF model has weeks of work in it, it
will — the correct fix is a separate *private* repository, or a private
submodule mounted here. Not un-ignoring the folder.

## What is here

```
projects/
  stf-digital-twin/     fischertechnik Training Factory 24V — CAD + MuJoCo
    cad/lib/            parametric fischertechnik part library (OpenSCAD)
    cad/stations/       station assemblies, built from lib/ on the 15 mm raster
    cad/out/            rendered PNG / STL — regenerable, never hand-edited
    sim/mjcf/           MuJoCo scene description
    sim/assets/         decimated meshes for the simulator
    control/            I/O map and sequences extracted from the PLC sources
    docs/               measurement sheet, decisions, assumptions
    reference/          photographs of the real cell
  _archive/             superseded work kept for provenance
```

## Rules that keep this useful

- **`cad/out/` is generated.** Never edit a file in it. If a render is wrong,
  the source is wrong.
- **Every uncertain dimension lives in `cad/lib/ft_params.scad`**, tagged
  `[EXACT]`, `[MEASURED]` or `[NOMINAL]`. Nowhere else. The whole point is that
  one lab session with a caliper corrects the entire model at once.
- **Physics geometry is never the visual geometry.** Collision shapes are
  primitives written directly into the MJCF. A fischertechnik beam is roughly
  2,000 triangles and MuJoCo wants a box.
- **Approximations are labelled where they are made.** Vacuum suction is a weld
  constraint; conveyors are a tangential velocity at contact. Both are standard
  and both are lies about the physics. They are written down as such in the
  MJCF comments so that nothing here quietly becomes a claim it cannot support.
