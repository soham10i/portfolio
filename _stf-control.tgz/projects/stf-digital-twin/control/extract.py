#!/usr/bin/env python3
"""Extract the machine-readable control model from fischertechnik's own PLC sources.

Why this exists: the simulation should be driven by the manufacturer's actual
I/O map and sequences, not by my reading of photographs. Everything this script
emits is derived, never hand-written, so re-running it after an upstream update
is the whole maintenance story.

Source: github.com/fischertechnik/plc_training_factory_24v  (PLC_SCL_sources/TP)
"""
import json, re, sys, pathlib, xml.etree.ElementTree as ET

SRC = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/plc/PLC_SCL_sources/TP")
OUT = pathlib.Path(__file__).parent

# ── I/O map ─────────────────────────────────────────────────────────────────
# The Belegungsplan, straight out of the TIA tag table. Each tag carries a
# remark of the form "STATION - Ix = human description", which is the only
# structure we need: station, terminal, meaning.
root = ET.parse(SRC / "PLCTags.xml").getroot()
tags = []
for t in root.findall("Tag"):
    remark = t.get("remark", "").strip()
    m = re.match(r"^([A-Z]{3})\s*-\s*([A-Z]?\d+)\s*=\s*(.+)$", remark)
    if not m:
        continue
    station, terminal, desc = m.groups()
    addr = t.get("addr", "")
    tags.append({
        "station": station,
        "terminal": terminal,
        "kind": "input" if addr.startswith("%I") else "output",
        "addr": addr,
        "symbol": (t.text or "").strip(),
        "desc": desc.strip(),
        "type": t.get("type"),
    })

# ── constants from the SCL ──────────────────────────────────────────────────
# Axis positions are in ENCODER PULSES, not millimetres. That is the single
# most useful thing in the whole repository: the rack bay pitch in pulses is
# exact, so one caliper reading of the real pitch in mm calibrates every axis
# in the model at once.
scl = (SRC / "Main.scl").read_text(errors="replace")

# The constants live inside per-station DATA_BLOCKs ("gtyp_VGR", "gtyp_HBW",
# …), so scope by the enclosing DB rather than flattening. The first version
# did flatten, and HBW's park position silently overwrote SSC's — identical
# symbol names in different DBs, which is exactly what scoping exists for.
def db_regions(text):
    marks = [(m.start(), m.group(1)) for m in
             re.finditer(r'^DATA_BLOCK "(\w+)"', text, re.M)]
    marks += [(m.start(), None) for m in
              re.finditer(r'^FUNCTION_BLOCK "', text, re.M)]
    marks.sort()
    out = []
    for i, (pos, name) in enumerate(marks):
        end = marks[i + 1][0] if i + 1 < len(marks) else len(text)
        if name:
            out.append((name, text[pos:end]))
    return out

REGIONS = db_regions(scl)

def grab_scoped(pattern):
    """{db: {symbol: value}} — re.M matters; without it "^" anchors to the
    start of the whole file and every one of these returns empty."""
    res = {}
    for db, body in REGIONS:
        hits = {m.group(1): int(m.group(2)) for m in re.finditer(pattern, body, re.M)}
        if hits:
            res.setdefault(db, {}).update(hits)
    return res

positions  = grab_scoped(r"^\s*(di_(?:Pos|Offset_Pos)[A-Za-z_0-9]*)\s*:=\s*(-?\d+);")
counters   = grab_scoped(r"^\s*(i_CounterValue[A-Za-z_]*)\s*:=\s*(-?\d+);")

softlimits = {}
windows = {}
for db, body in REGIONS:
    for m in re.finditer(r"^\s*(\w+_Axis)\.Config\.di_Pos_(Soft_Switch|Window)\s*:=\s*(-?\d+);", body, re.M):
        ax, kind, val = m.groups()
        (softlimits if kind == "Soft_Switch" else windows).setdefault(db, {})[ax] = int(val)

rack = {}
for db, body in REGIONS:
    for m in re.finditer(r"di_PosRack_([A-Z]\d)_(Horizontal|Vertical)\s*:=\s*(-?\d+);", body):
        bay, axis, val = m.groups()
        rack.setdefault(bay, {})[axis.lower()] = int(val)
    for m in re.finditer(r"Rack_Pos\[(\d),(\d)\]\.di_PosRack_(Horizontal|Vertical)\s*:=\s*(-?\d+);", body):
        r_, c_, axis, val = m.groups()
        rack.setdefault(f"R{r_}C{c_}", {})[axis.lower()] = int(val)

timers = sorted({m.group(0) for m in re.finditer(r"T#\d+(?:ms|s)\b", scl)},
                key=lambda s: (0 if s.endswith("ms") else 1, int(re.sub(r"\D", "", s))))

blocks = [m.group(1) for m in re.finditer(r'^FUNCTION_BLOCK "(PRG_[A-Za-z_]+)"', scl, re.M)]

# ── step tables: the state machine of each station's Ablauf ────────────────
sequences = {}
for m in re.finditer(r'^FUNCTION_BLOCK "(PRG_(\w+)_Ablauf)"', scl, re.M):
    name, station = m.group(1), m.group(2)
    start = m.end()
    nxt = scl.find("FUNCTION_BLOCK", start)
    body = scl[start: nxt if nxt > 0 else len(scl)]
    steps = [{"step": int(s), "comment": c.strip()}
             for s, c in re.findall(r"^\s*(\d+):\s*//\s*(.+)$", body, re.M)]
    if steps:
        sequences[station] = {"block": name, "steps": steps}

model = {
    "source": "github.com/fischertechnik/plc_training_factory_24v @ PLC_SCL_sources/TP",
    "note": "Derived by control/extract.py. Do not hand-edit.",
    "units": {"positions": "encoder pulses", "times": "IEC TIME literals"},
    "io": tags,
    "axis_positions_pulses": positions,
    "axis_soft_limits_pulses": softlimits,
    "axis_position_window_pulses": windows,
    "rack_positions_pulses": rack,
    "sld_counter_values": counters,
    "timer_literals": timers,
    "program_blocks": blocks,
    "sequences": sequences,
}
(OUT / "control-model.json").write_text(json.dumps(model, indent=2) + "\n")

# ── human-readable I/O map ─────────────────────────────────────────────────
lines = ["# I/O map (Belegungsplan) — extracted, not transcribed", "",
         "Generated by `control/extract.py` from fischertechnik's own TIA tag table.",
         "Do not edit by hand; re-run the script.", ""]
for st in ["VGR", "HBW", "MPO", "SLD", "DPS", "SSC"]:
    rows = [t for t in tags if t["station"] == st]
    if not rows:
        continue
    ins = [t for t in rows if t["kind"] == "input"]
    outs = [t for t in rows if t["kind"] == "output"]
    lines += [f"## {st} — {len(ins)} inputs, {len(outs)} outputs", "",
              "| Terminal | Dir | PLC address | Meaning |", "|---|---|---|---|"]
    for t in rows:
        lines.append(f"| {t['terminal']} | {'I' if t['kind']=='input' else 'Q'} | `{t['addr']}` | {t['desc']} |")
    lines.append("")
(OUT / "io-map.md").write_text("\n".join(lines) + "\n")

print(f"tags={len(tags)}  stations={sorted({t['station'] for t in tags})}")
print(f"position DBs={list(positions)}  rack_bays={len(rack)}  sequences={list(sequences)}")
print(f"timers={timers}")
