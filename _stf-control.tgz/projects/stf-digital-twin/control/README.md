# Control model — extracted from fischertechnik's own PLC sources

Everything in this folder except this file and `extract.py` is **generated**.
Re-run `python3 extract.py /path/to/PLC_SCL_sources/TP` after any upstream
change; never hand-edit the outputs.

| File | What it is |
|---|---|
| `control-model.json` | machine-readable: I/O map, axis constants, sequences |
| `io-map.md` | the Belegungsplan, readable |
| `extract.py` | the extractor — the only hand-written thing here |

**Source:** [`fischertechnik/plc_training_factory_24v`](https://github.com/fischertechnik/plc_training_factory_24v),
path `PLC_SCL_sources/TP` (the current "TP" configuration; an older "IM"
configuration sits alongside it and differs slightly).

> **Licence, unresolved.** That repository has no LICENSE file. It is published
> by fischertechnik as customer material, but "published" is not "licensed".
> Using it privately to build a simulation is one thing; redistributing derived
> constants in a public repository is another. **Resolve this before anything
> here reaches a public artefact** — the contact address in their README is
> `fischertechnik-technik@fischer.de`. Until then, `projects/` staying
> gitignored is doing real work, not just tidiness.

---

## What came out

**89 I/O points across five stations** — VGR, HBW, MPO, SLD, SSC — each with
its terminal number, PLC address and an English description written by the
manufacturer. This supersedes the 9 DI / 14 DO figure the portfolio currently
quotes: that was MPO alone.

**DPS has no PLC I/O.** The Delivery and Pickup Station is driven by the TXT
controller over MQTT, not by the S7-1500. Anything DPS-related has to come from
`TxtGatewayPLC/`, not from here. Worth knowing before looking for tags that do
not exist.

**Five step-table sequences**, as the manufacturer wrote them:

| Station | Block | Steps |
|---|---|---|
| VGR | `PRG_VGR_Ablauf` | 102 |
| MPO | `PRG_MPO_Ablauf` | 31 |
| HBW | `PRG_HBW_Ablauf` | 27 |
| SSC | `PRG_SSC_Ablauf` | — |
| SLD | `PRG_SLD_Ablauf` | 10 |

The MPO sequence is the process the simulation has to reproduce, and it is
completely explicit — open oven door, retract feeder, close door, processing
interval, extend feeder, suction down, pick, up, traverse to turn-table, suction
off, position turn-table to saw, saw, and so on. No guessing required.

---

## The useful part: positions are in encoder pulses

Every axis target in the PLC is a **pulse count**, not a millimetre. That is
better than it sounds, because pulse counts are exact and mine to use directly
as joint targets, while the millimetres are the thing I can measure once and
convert.

### HBW rack — the calibration key

| | Column 1 | Column 2 | Column 3 |
|---|---|---|---|
| **Row 1** | 2870 / 400 | 5200 / 400 | 7550 / 400 |
| **Row 2** | 2870 / 1750 | 5200 / 1750 | 7550 / 1750 |
| **Row 3** | 2870 / 3150 | 5200 / 3150 | 7550 / 3150 |

*(horizontal / vertical, in pulses)*

Derived pitch:

- **horizontal:** 5200 − 2870 = 2330, 7550 − 5200 = 2350 → **2340 ± 10 pulses**
- **vertical:** 1750 − 400 = 1350, 3150 − 1750 = 1400 → **1375 ± 25 pulses**

The vertical spread is 3.6%, which is not measurement noise in a constant table —
it is a deliberate hand-tune, presumably for belt sag or rack flex. Do not
"correct" it to a uniform pitch; reproducing the asymmetry is part of
reproducing the machine.

**This is the bridge.** One caliper reading of the real bay pitch in millimetres
(item E7 on the measurement sheet) gives pulses-per-mm for the HBW horizontal
axis, and every other HBW constant converts with it. The same trick works per
axis, per station.

There is also a discrepancy worth noting: the `gtyp_HBW` declared defaults give
bay C3 as 7560 / 3250, while the runtime `Rack_Pos[3,3]` array sets 7550 / 3150.
Both are in the extract. The array assignment is what actually runs.

### Axis travel limits (soft switches, pulses)

| Station | Horizontal | Vertical | Rotate |
|---|---|---|---|
| HBW | 7900 | 3350 | — |
| SSC | 5450 | 3000 | — |
| VGR | 20000 | 20000 | 20000 |

HBW and SSC are real limits and give the joint ranges directly. **The VGR's
20000 on all three axes is not a real limit** — it is a "no soft limit"
sentinel, three orders above its actual working positions (its targets run
150–5350). VGR joint limits must come from measurement (items E1–E3), not from
here. Taking 20000 at face value would let the simulated gripper drive straight
through the rack.

### VGR target positions — 37 of them

Named targets for every place the gripper goes: `DSI` (delivery in), `DSO`
(delivery out), `Color`, `NFC`, `MPO`, `HBW`, `SLD_Blue` / `SLD_Red` /
`SLD_White`, `NiO` (nicht in Ordnung — the reject drop), and `Park`. Each has
horizontal, vertical and rotate values, several with a separate approach offset.

This is the entire VGR motion plan, already written down. It is the difference
between animating a robot arm and reproducing one.

### SLD — the sorting line, in belt pulses

```
i_CounterValue_White = 5      i_CounterValue_Red = 16      i_CounterValue_Blue = 26
```

These are conveyor encoder counts from the colour sensor to each ejector, so
they are the **physical spacing of the three ejectors along the belt**: gaps of
11 and 10 pulses between them, white nearest the sensor. Ejector positions in
the model can be laid out from these and then scaled by one belt measurement.

### Timers actually used

`50ms · 200ms · 300ms · 500ms · 1s · 2s · 4s · 5s · 20s · 30s · 60s`

The long ones are the interesting ones. The 500 ms literal appears 26 times — it
is the generic settle/debounce wait. Which timer belongs to which step still has
to be read out of the step tables; the extractor collects the vocabulary, not
yet the assignment.

---

## What this does not give us

Being clear about the gaps, because they are the reason the lab session still
matters:

- **No millimetres.** Every position is a pulse count. Without one measurement
  per axis the model has correct *proportions* and arbitrary *scale*.
- **No masses, no friction.** Nothing in a PLC program knows what a puck weighs.
- **No belt speed in mm/s.** The PLC counts pulses; the physics needs velocity.
- **No VGR joint limits**, per the sentinel problem above.
- **Timer-to-step assignment** is not yet extracted — a second pass over the
  step tables, which is worth doing before the MJCF and is not hard.

Items E1–E3, E7, C4 and F8/F11 on the measurement sheet are precisely the
numbers that close these gaps. That is not a coincidence — the sheet was
written first, and this extraction confirms it asked for the right things.
